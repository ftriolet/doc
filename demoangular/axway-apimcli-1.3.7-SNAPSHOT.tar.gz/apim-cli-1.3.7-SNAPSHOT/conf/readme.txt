#
# To learn more about environment properties 
# visit: 
# https://github.com/Axway-API-Management-Plus/apim-cli/wiki/8.2.-Environment-property-files
#
